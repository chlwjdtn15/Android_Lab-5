package com.example.lab5;

public class NameData {

    String name = "";



    public NameData(String name) {
        this.name = name;
    }




}
